import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Cliente extends Thread {
	ArrayList<Producto> carrito = new ArrayList<Producto>();
	float[] cesta;
	int tiempoespera;
	float ticket = 0;
	int tiempototal = 0;
	int id;

	public Cliente(int c, int t) {
		id = c;
		tiempoespera = t;
		int aleatorio = (int) (Math.random() * 10 + 1);
		int NombreAleatorio;
		String nombre = "";
		float precio;
		cesta = new float[aleatorio];

		for (int i = 0; i < aleatorio; i++) {
			cesta[i] = Math.round((Math.random() * 10 + 1) * 100d / 100d);
			precio = Math.round((Math.random() * 10 + 1) * 100d / 100d);
			NombreAleatorio = (int) (Math.random() * 10 + 1);
			switch (NombreAleatorio) {
			case 1:
				nombre = "Pan";
				break;
			case 2:
				nombre = "Jam�n";
				break;
			case 3:
				nombre = "Huevos";
				break;
			case 4:
				nombre = "Aceite";
				break;
			case 5:
				nombre = "Doritos";
				break;
			case 6:
				nombre = "Pringles";
				break;
			case 7:
				nombre = "Tomate";
				break;
			case 8:
				nombre = "Sand�a";
				break;
			case 9:
				nombre = "Tortelinis";
				break;
			case 10:
				nombre = "Salsa Bolo�esa";
				break;
			}
			carrito.add(new Producto(precio, nombre));
		}
	}

	@Override
	public void run() {
		for (Producto aux : carrito) {
			try {
				Thread.sleep(tiempoespera);
				System.out.println("Caja"+"->"+id+" "+aux.nombre + " : " + aux.precio + "�");
				tiempototal += tiempoespera/1000;
				ticket += aux.precio;
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	public float getTicket() {
		return ticket;
	}

	public int getTiempototal() {
		return tiempototal;
	}
	
}
