
public class Producto {
	float precio;
	String nombre;
	public Producto() {
		
	}
	public Producto(float precio, String nombre) {
	this.precio = precio;
	this.nombre = nombre;
}

}
