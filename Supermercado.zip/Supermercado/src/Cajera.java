public class Cajera extends Thread {
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		Cliente c1 = new Cliente(1,500);
		Cliente c2 = new Cliente(2,1000);
		//for (float aux : c1.cesta) {
		//	System.out.println(aux + "�");
		//}
		//for (Producto aux : c2.carrito) {
		//	System.out.println(aux.nombre +" : "+ aux.precio + "�");
		//}
		c1.start();
		c2.start();
		Cliente.sleep(20000);
		System.out.println("Factura total Cajera 1  : "+ c1.getTicket());;
		System.out.println("Factura total Cajera 2  : "+ c2.getTicket());
		
	}

}
